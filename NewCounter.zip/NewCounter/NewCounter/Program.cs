﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewCounter
{
    class Program
    {
        static void Main(string[] args)
        {
            
            
                Counter c = new Counter();
                Console.Write("请输入X: ");
                c.X = Console.ReadLine();
                Console.Write("请输入Y: ");
                c.Y = Console.ReadLine();
                Console.WriteLine("请输入下一步操作: ");
                c.MathSign = char.Parse(Console.ReadLine());
                c.counter();
                c = null; 
                Console.WriteLine();
            
        }

    }
}
